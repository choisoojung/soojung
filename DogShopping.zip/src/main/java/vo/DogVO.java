package vo;

public class DogVO {
	private int dogId;
	private String dogKind;
	private int dogPrice;
	private String dogImage;
	private String dogCountry;
	private int dogHeight;
	private int dogWeight;
	private String dogContent;
	private int dogReadCount;
	public int getDogId() {
		return dogId;
	}
	public void setDogId(int dogId) {
		this.dogId = dogId;
	}
	public String getDogKind() {
		return dogKind;
	}
	public void setDogKind(String dogKind) {
		this.dogKind = dogKind;
	}
	public int getDogPrice() {
		return dogPrice;
	}
	public void setDogPrice(int dogPrice) {
		this.dogPrice = dogPrice;
	}
	public String getDogImage() {
		return dogImage;
	}
	public void setDogImage(String dogImage) {
		this.dogImage = dogImage;
	}
	public String getDogCountry() {
		return dogCountry;
	}
	public void setDogCountry(String dogCountry) {
		this.dogCountry = dogCountry;
	}
	public int getDogHeight() {
		return dogHeight;
	}
	public void setDogHeight(int dogHeight) {
		this.dogHeight = dogHeight;
	}
	public int getDogWeight() {
		return dogWeight;
	}
	public void setDogWeight(int dogWeight) {
		this.dogWeight = dogWeight;
	}
	public String getDogContent() {
		return dogContent;
	}
	public void setDogContent(String dogContent) {
		this.dogContent = dogContent;
	}
	public int getDogReadCount() {
		return dogReadCount;
	}
	public void setDogReadCount(int dogReadCount) {
		this.dogReadCount = dogReadCount;
	}
}
